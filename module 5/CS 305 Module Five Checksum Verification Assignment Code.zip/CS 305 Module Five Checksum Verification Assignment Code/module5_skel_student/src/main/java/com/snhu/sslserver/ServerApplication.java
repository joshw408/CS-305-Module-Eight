package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class ServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServerApplication.class, args);
    }

}

@RestController
class ServerController {
    //return checksum
    @RequestMapping("/hash")
    public String myHash() {
        String data = "Hello Joshua Williamson!";
        try {
            //MessageDigest with SHA-256
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            //hash bytes
            byte[] digest = md.digest(data.getBytes(StandardCharsets.UTF_8));
            //convert to hex
            String hashHex = bytesToHex(digest);
            //return HTML response
            return "<p>data: " + data + "</p><p>SHA-256: " + hashHex + "</p>";
        } catch (NoSuchAlgorithmException e) {
            return "Error: " + e.getMessage();
        }
    }

    //method to convert bytes to hex
    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
